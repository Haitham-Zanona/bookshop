__('Manage Website', 'elementor');
__('More', 'elementor');
__('Elementor Logo', 'elementor');